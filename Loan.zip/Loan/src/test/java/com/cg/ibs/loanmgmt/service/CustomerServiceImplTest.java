 package com.cg.ibs.loanmgmt.service;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanType;
import com.cg.ibs.loanmgmt.exception.IBSException;

class CustomerServiceImplTest {
	private static CustomerServiceImpl customerService = new CustomerServiceImpl();
	Loan loanTemp = new HomeLoan();
	LoanMaster loanMasterTemp = new LoanMaster();
	CustomerBean customerTemp = new CustomerBean();

	// HOME_LOAN
	@Test
	public void emiHLTest() {

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);
		assertEquals(1103.6846021816305, actual);

	}

	@Test
	public void emiHLNegativeTest() {
		Loan loanTemp = new HomeLoan();

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);
		assertNotEquals(89189, actual);
	}

	@Test
	public void validCustomerHLTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		boolean actual = customerService.loanCustomerInputVerificationService(loanTemp);
		assertEquals(true, actual);
	}

	@Test
	public void notValidCustomerHLTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(1561899);
		loanTemp.setLoanTenure(13);
		boolean actual = customerService.loanCustomerInputVerificationService(loanTemp);
		assertNotEquals(true, actual);
	}

	// VEHICLE_LOAN
	@Test
	public void emiVLTest() {
		Loan loanTemp = new VehicleLoan();

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);

		assertEquals(1108.0815900950197, actual);

	}

	@Test
	public void emiVLNegativeTest() {
		Loan loanTemp = new VehicleLoan();

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);
		assertNotEquals(11058, actual);
	}

	@Test
	public void validCustomerVLTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		boolean actual = customerService.loanCustomerInputVerificationService(loanTemp);
		assertEquals(true, actual);
	}

	@Test
	public void notValidCustomerVLTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(12654896);
		loanTemp.setLoanTenure(128);
		boolean actual = customerService.loanCustomerInputVerificationService(loanTemp);
		assertNotEquals(true, actual);
	}

	@Test
	public void emiPLTest() {
		Loan loanTemp = new PersonalLoan();

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);

		assertEquals(1116.9056586284007, actual);

	}

	@Test
	public void emiPLNegativeTest() {
		Loan loanTemp = new PersonalLoan();

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);
		assertNotEquals(11058, actual);
	}

	@Test
	public void validCustomerPLTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		boolean actual = customerService.loanCustomerInputVerificationService(loanTemp);
		assertEquals(true, actual);
	}

	@Test
	public void notValidCustomerPLTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(1265489654);
		loanTemp.setLoanTenure(13);
		boolean actual = customerService.loanCustomerInputVerificationService(loanTemp);
		assertNotEquals(true, actual);
	}

	// EDUCATION_LOAN
	@Test
	public void emiELTest() {
		Loan loanTemp = new EducationLoan();

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);

		assertEquals(1120.4517435964037, actual);

	}

	@Test
	public void emiELNegativeTest() {
		Loan loanTemp = new EducationLoan();

		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		double actual = customerService.calculateEmi(loanTemp);
		assertNotEquals("garbage", actual);
	}

	@Test
	public void validCustomerELTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(12654);
		loanTemp.setLoanTenure(12);
		assertTrue(customerService.loanCustomerInputVerificationService(loanTemp));

	}

	@Test
	public void notValidCustomerELTest() {
		Loan loanTemp = new EducationLoan();
		loanTemp.setLoanAmount(99999999);
		loanTemp.setLoanTenure(33);
		assertFalse(customerService.loanCustomerInputVerificationService(loanTemp));

	}

//	@Test
//	public void documentUploadTest() {
//		Document documentTemp = new Document();
//		String voterId = "Votercard";
//		String pathOfDocument = "C://Users//user//Desktop//sample1.pdf ";
//		documentTemp.setNameOfDocument(voterId);
//		documentTemp.setPathOfDocument(pathOfDocument);
//		try {
//			boolean result = customerService.uploadDocument(documentTemp, loanMasterTemp);
//			assertEquals(true, result);
//		} catch (IBSException exp) {
//			fail("Test Failed: " + exp.getMessage());
//		}
//	}

//	@Test
//	public void getDocumentFailureTest() {
//		Document documentTemp = new Document();
//		String voterId = "VoterIDCard";
//		String pathOfDocument = "C://Users//Lenovo//Downloads//sample1.pdf";
//		documentTemp.setNameOfDocument(voterId);
//		documentTemp.setPathOfDocument(pathOfDocument);
//		try {
//			boolean result = customerService.getDocument(documentTemp);
//			assertEquals(false, result);
//		} catch (IBSException exp) {
//			fail("Test Failed: " + exp.getMessage());
//		}
//	}

	@Test
	public void loanVerifiedTest() throws FileNotFoundException, IOException, IBSException {
		customerTemp.setUserId("ykalra");
		customerTemp.setFirstName("Yuvraj");
		customerTemp.setLastName("Kalra");
		customerTemp.setUCI(new BigInteger("94456812896"));
		loanMasterTemp.setCustomerBean(customerTemp);
		loanMasterTemp.setApplicationNumber(998);
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.PERSONAL_LOAN);
		loanMasterTemp.setEmiAmount(23245.0);
		loanMasterTemp.setInterestRate(10.75f);
		loanMasterTemp.setLoanAmount(500000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(999);
		loanMasterTemp.setNumberOfEmis(23);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		boolean actual = customerService.sendLoanForVerification(loanMasterTemp);
		assertTrue(actual);
	}

//	@Test
//	public void loanNotVerifiedTest() throws FileNotFoundException, IOException, IBSException {
//	
//		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
//		loanMasterTemp.setLoanType(LoanType.PERSONAL_LOAN);
//		loanMasterTemp.setEmiAmount(23245.0);
//		loanMasterTemp.setInterestRate(10.75f);
//		loanMasterTemp.setLoanAmount(500000);
//		loanMasterTemp.setLoanTenure(24);
//		loanMasterTemp.setLoanNumber(999);
//		CustomerBean customerBean = new CustomerBean("Dev", "Goyal", null, "dgoyal");
//		loanMasterTemp.setCustomerBean(customerBean);
//		loanMasterTemp.setNumberOfEmis(23);
//		loanMasterTemp.setTotalNumberOfEmis(24);
//		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
//		boolean actual = customerService.sendLoanForVerification(loanMasterTemp);
//		assertNull(actual);
//	}

	@Test
	public void loanValuesNotNullTest() throws SQLException, IBSException {
		loanTemp.setEmiAmount(21917.0);
		loanTemp.setLoanAmount(1000000.00);
		loanTemp.setLoanTenure(60);
		loanTemp.setLoanType(LoanType.EDUCATION_LOAN);
		LoanMaster actual = customerService.getLoanValues(loanTemp, "ykalra");
		assertNotNull(actual);
	}

	@Test
	public void loanValuesNullTest() throws SQLException, IBSException {
		loanTemp.setEmiAmount(96896.0);
		loanTemp.setLoanAmount(1000.00);
		loanTemp.setLoanTenure(60);
		loanTemp.setLoanType(LoanType.EDUCATION_LOAN);
		LoanMaster actual = customerService.getLoanValues(loanTemp, "dgoyal");
		assertNotEquals("dgoyal",actual.getCustomerBean().getUserId());
	}

	@Test
	public void customerPositiveTest() throws IBSException {
		boolean actual = customerService.verifyCustomer("ckohli");
		Assertions.assertEquals(true, actual);
	}

	@Test
	public void customerNegTest() throws IBSException {
		boolean actual = customerService.verifyCustomer("dgoyal");
		Assertions.assertNotEquals(true, actual);
	}

//	@Test
//	public void emiApplicableNotNullTest() {
//		loanMasterTemp = new LoanMaster(998, LoanType.VEHICLE_LOAN, 1000000.00, 24, 45800.0,
//				new CustomerBean("Chetan", "Kohli", new BigInteger("12346"), "ckohli"), 16, 24, LocalDate.of(2018, 6, 15),
//				LocalDate.now());
//		
//		LoanMaster actual = customerService.verifyEmiApplicable(998);
//		System.out.println(actual);
//		
//		assertNotNull(actual);
//	}

	@Test
	public void verifyLoanNumberTest() {
		loanMasterTemp.setLoanNumber(1000);
		boolean actual = customerService.verifyLoanNumber(loanMasterTemp.getLoanNumber());
		assertEquals(true, actual);
	}

	@Test
	public void verifyLoanNumberNegTest() {
		loanMasterTemp.setLoanNumber(1000);
		boolean actual = customerService.verifyLoanNumber(loanMasterTemp.getLoanNumber());
		assertNotEquals(false, actual);
	}

	@Test
	public void preclosureTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Yuvraj","Kalra", new BigInteger("944486932517"), "ykalra");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		double actual = customerService.calculatePreClosure(loanMasterTemp);
		assertEquals(1158400.640604138, actual);
	}

	@Test
	public void preclosureNegativeTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Dev","Goyal", new BigInteger("966325874125"),"dgoyal");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		double actual = customerService.calculatePreClosure(loanMasterTemp);
		assertNotEquals(110.60, actual);
	}

	@Test
	public void verifyPreclosureTest() throws FileNotFoundException, IOException{
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Yuvraj","Kalra", new BigInteger("944486932517"), "ykalra");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		boolean actual = customerService.sendPreClosureForVerification(loanMasterTemp);
		assertEquals(true, actual);

	}

	@Test
	public void falsePreclosureTest() throws FileNotFoundException, IOException {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Dev","Goyal", new BigInteger("966325874125"),"dgoyal");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		boolean actual = customerService.sendPreClosureForVerification(loanMasterTemp);
		assertNotEquals(false, actual);

	}

//	@Test
//	public void preclosureExceptionTest() throws FileNotFoundException, IOException {
//		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
//		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
//		loanMasterTemp.setEmiAmount(78954.00);
//		loanMasterTemp.setInterestRate(8.5f);
//		loanMasterTemp.setLoanAmount(2000000);
//		loanMasterTemp.setLoanTenure(24);
//		loanMasterTemp.setLoanNumber(1234);
//		CustomerBean customerBean = new CustomerBean("Dev","Goyal", new BigInteger("966325874125"),"dgoyal");
//		loanMasterTemp.setCustomerBean(customerBean);
//		loanMasterTemp.setNumberOfEmis(13);
//		loanMasterTemp.setTotalNumberOfEmis(24);
//		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
//		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("./PreClosureDetailsXYZ.dat"));
//		out.writeObject(loanMasterTemp);
//		out.close();
//		LoanMaster loanMasterActual = null;
//		assertThrows(ClassCastException.class, () -> {
//			customerService.sendPreClosureForVerification(loanMasterTemp);
//		});
//	}

	@Test
	public void preClosureNullTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanNumber(1000);
		LoanMaster actual = customerService.getPreClosureLoanDetails(loanMasterTemp.getLoanNumber());
		assertNotNull(actual);
	}
	

//	@Test
//	public void wrongHistoryTest() {
//		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
//		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
//		loanMasterTemp.setEmiAmount(78954.00);
//		loanMasterTemp.setInterestRate(8.5f);
//		loanMasterTemp.setLoanAmount(2000000);
//		loanMasterTemp.setLoanTenure(24);
//		loanMasterTemp.setLoanNumber(997);
//		CustomerBean customerBean = new CustomerBean("Dev", "Goyal", "1234", "dgoyal");
//		loanMasterTemp.setCustomerBean(customerBean);
//		loanMasterTemp.setNumberOfEmis(13);
//		loanMasterTemp.setTotalNumberOfEmis(24);
//		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
//		List<LoanMaster> actual = customerService.getHistory(loanMasterTemp.setLoanNumber(997));
//		assertNotEquals(true, actual);
//	}

	@Test
	public void updateEMINotNullTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.PERSONAL_LOAN);
		loanMasterTemp.setEmiAmount(23245.0);
		loanMasterTemp.setInterestRate(10.75f);
		loanMasterTemp.setLoanAmount(500000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(999);
		CustomerBean customerBean = new CustomerBean("Yuvraj","Kalra", new BigInteger("944486932517"), "ykalra");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(23);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		boolean actual = customerService.updateEMI(23245.0, loanMasterTemp);
		assertTrue(actual);

	}

	@Test
	public void updateEMINullTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.PERSONAL_LOAN);
		loanMasterTemp.setEmiAmount(23245.0);
		loanMasterTemp.setInterestRate(10.75f);
		loanMasterTemp.setLoanAmount(500000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(999);
		CustomerBean customerBean = new CustomerBean("Dev", "Goyal", new BigInteger("12347"), "dgoyal");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(23);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		boolean actual = customerService.updateEMI(8965.0, loanMasterTemp);
		
		assertFalse(actual);
	}

	@Test
	public void customerDetailsNotNullTest() throws SQLException, IBSException {
		customerTemp.setUserId("ykalra");
		CustomerBean actual = customerService.getCustomerDetails(customerTemp.getUserId());
		
		assertNotNull(actual.getUCI());
	}

	@Test
	public void customerDetailsNullTest() throws SQLException, IBSException {
		customerTemp.setUserId("dgupta");
		CustomerBean actual = customerService.getCustomerDetails(customerTemp.getUserId());
		
		assertNotEquals("dgupta",actual.getUCI());
	}



	


	@Test
	public void getDocumentForEmptyDocumentDetailsTest() {
		Document documentTemp = new Document();
		assertNull(documentTemp.getNameOfDocument());
	}

	@Test
	public void getDocumentForEmptyDocumentTest() {
		Document documentTemp = new Document();
		assertNotNull(documentTemp);
	}

}