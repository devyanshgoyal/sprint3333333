package com.cg.ibs.loanmgmt.service;

import com.cg.ibs.loanmgmt.bean.LoanBean;

public interface LoanService {
	public Loan setLoanDetails(LoanBean loanBean);
	
}
